# TX-2 toolchain 0.3.0

Self-contained ESM package, no runtime dependencies. Not a complete TX-2 machine or a working original Sketchpad restoration. Read docs/COMPATIBILITY.md.

```js
import {assemble, TX2} from '@sketchpad-lab/tx2-toolchain';
const image=assemble('.org 100\nLDA 200\n.org 200\n.word 123');
if(image.diagnostics.length) throw new Error(JSON.stringify(image.diagnostics));
const machine=new TX2();
machine.load(image);
console.log(machine.step(), machine.getRegister('A'));
machine.back();
```

CLI: `tx2-assemble source.tx2 output.tx2.json`. Image JSON is a modern interchange format. Use the CLI flag `--tape` to emit a standard reader-leader binary tape, and `TX2.bootTape(bytes)` in the INOUT research profile to execute the published bootstrap. See docs/TAPE.md; this does not boot the complete original Sketchpad program.
